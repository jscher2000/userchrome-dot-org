// config-prefs.js file for [Firefox program folder]\defaults\pref
pref("general.config.obscure_value", 0);
// the file named in the following line must be in [Firefox program folder]
pref("general.config.filename", "config1.js");
// disable the sandbox to run unsafe code
pref("general.config.sandbox_enabled", false);
